<?php
    $saludo = $_GET['saludo'];
    echo $saludo;
?>